This project implements the Set card game in Ruby. Players identify sets of cards based on their attributes. The game supports two players, keeps track of scores, and ends when no more cards are available.

It can be run by entering "ruby main.rb" in the terminal

How to play:

A set is a group of three cards where each of the four attributes match the following:

1. All match across the three cards
2. All are different across the three cards

The attributes are as follows:
Number: 1, 2, 3
Shape: Oval (O), Square (S), Diamond (D)
Shading: Solid (SOL), STriped (STR), Open (OPE)
Color: Red (R), Green (G), Purple (P)

Examples of sets:

1. Valid set
Card 1: 2, D, SOL, R
Card 2: 1, D, SOL, P
Card 3: 3, D, SOL, G

Numbers are all different, shapes are all the same, shadings are all the same, colors are all different

2. Invalid set
Card 1: 2, D, SOL, P
Card 2: 1, D, SOL, P
Card 3: 2, D, SOL, G

Since the numbers and colors aren't all different or the same, this set is invalid

Simple Game Flow:

Add Players
Start Game: Deal 12 cards
Select Cards: Players are asked to select 3 different cards. The game will check if the set is correct or incorrect
Correct Set: Player scores a point, replace the 3 cards that were used, next players turn
Incorrect set: Player gets no points, no cards replaced, next players turn
End Game: The game ends when no more sets can be found and the deck is empty. Whichever player has the highest score wins.
