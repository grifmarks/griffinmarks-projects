require_relative 'lib/game'

game = Game.new
game.add_players
game.start