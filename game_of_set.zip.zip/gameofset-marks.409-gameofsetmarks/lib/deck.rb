require_relative 'card'

class Deck
    SHAPES = ['O', 'S', 'D'] # oval, squiggle, diamond
    COLORS = ['R', 'G', 'P'] # red, green, purple
    SHADINGS = ['SOL', 'STR', 'OPE'] # solid, striped, open
    NUMBERS = [1, 2, 3]

    def initialize
        @cards = []
        NUMBERS.each do |number|
            SHAPES.each do |shape|
                COLORS.each do |color|
                    SHADINGS.each do |shading|
                        @cards << Card.new(number, shape, shading, color)
                    end
                end
            end
        end
        @cards.shuffle!
    end

    def deal(num)
        @cards.pop(num)
    end

    def empty?
        @cards.empty?
    end
end
