require_relative 'player_creator'
require_relative 'deck'
require_relative 'card'

class Game

    def initialize
        @player_creator = PlayerCreator.new
        @deck = Deck.new
        @cards_dealt = []
        @score = Hash.new(0)
    end

    def add_players
        @players = @player_creator.get_players
        puts "Welcome #{@players.join(' and ')}"
    end

    def start
        @cards_dealt = @deck.deal(12)
        loop do
            display_table
            if deck_empty? && !sets_available?
                puts "No more sets and the deck is empty!"
                break
            end
            play_turn
            ensure_valid_set_on_table
        end
        display_winner
    end

    def display_table
        puts "Cards on the table:"
        @cards_dealt.each_with_index do |card, index|
            puts "#{index + 1}: #{card}"
        end
    end

    def deck_empty?
        @deck.empty?
    end

    def sets_available?
        (0..@cards_dealt.length - 1).to_a.combination(3).any? do |indices|
            valid_set?(@cards_dealt.values_at(*indices))
        end
    end

    def play_turn
        current_player = @players.first

        puts "#{current_player}, choose 3 cards by their numbers separated by spaces (or type hint for help):"
        input = gets.chomp

        if input.downcase == 'hint'
          provide_hint
          return
        end
    
        indices = input.split.map(&:to_i).map { |i| i - 1 }

        if indices.uniq.size != 3
            puts "You must select 3 different cards."
            return
        end

        if valid_set?(@cards_dealt.values_at(*indices))
            puts "Correct set!"
            @score[current_player.name] += 1
            replace_cards(indices)
        else
            puts "Incorrect set."
        end

        rotate_players
    end

    def replace_cards(indices) # Remove invalid cards from table
        indices.each do |i|
            if @deck.empty?
                @cards_dealt[i] = nil
            else
                @cards_dealt[i] = @deck.deal(1).first
            end
        end
        @cards_dealt.compact!
    end

    def rotate_players
        @players.rotate!
    end

    def valid_set?(cards)
        cards.map(&:number).uniq.size != 2 &&
        cards.map(&:shape).uniq.size != 2 &&
        cards.map(&:shading).uniq.size != 2 &&
        cards.map(&:color).uniq.size != 2
    end

    def ensure_valid_set_on_table # Reshuffle if no valid set
        unless sets_available?
          puts "No valid set on the table. Replacing all cards..."

          @cards_dealt.each { |card| @deck.return_to_deck(card) }

          @cards_dealt = @deck.deal(12)
          
          @deck.shuffle!
        end
      end

    def display_winner
        puts "Game over! Final scores:"
        @score.each do |player_name, score|
            puts "#{player_name}: #{score} points"
        end
        winner = @score.max_by { |_player, score| score }.first
        puts "The winner is #{winner}!"
    end

    def provide_hint
        hint_card, hint_index, sets_count = find_hint
        if hint_card
          puts "Hint: Card #{hint_index + 1}: #{hint_card} is part of #{sets_count} set(s)."
        else
          puts "No sets available for a hint."
        end
      end
    
      # Find a card that's part of a valid set and how many sets it belongs to
      def find_hint
        @cards_dealt.each_with_index do |card, index|
          sets_count = count_sets_with_card(card)
          return [card, index, sets_count] if sets_count > 0
        end
        nil
      end
    
      def count_sets_with_card(card)
        other_cards = @cards_dealt - [card]
        other_cards.combination(2).count do |pair|
          valid_set?([card, *pair])
        end
      end



end