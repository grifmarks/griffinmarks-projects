# Project #4 Faculty Page Redesign

This project is a redesign of a existing CSE faculty member's website. Information includes the faculty's personal info, biography, and expertise. The redesign focuses on converting the current layout into a more visually pleasing format. Besides, the redesign involves more ruby related content to avoid code reuse.


### Structure of the redesigned website
    bio.html
    expertise.html
    index.html


### To run this application, inside the terminal run:

    bundle exec middleman build
    bundle exec middleman server

Then the website is hosted on: http://localhost:4567/


### Contributions

* Sai: index page
* Griffin: biography page
* Baicheng: expertise page