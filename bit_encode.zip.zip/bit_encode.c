/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF THE ** WORK TO
CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN THIS
** FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE INSTRUCTOR ** OR GRADERS
OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE TENURES OF THE ** OHIO STATE UNIVERSITY’S
ACADEMIC INTEGRITY POLICY. */

#include <stdio.h>

	// Prints the given cleartext input as hex characters
void printHex(char text[], int length) {
	for(int i=1; i<=length; i++){	// Loop through cleartext input
		int val = text[i];
		printf("%02x ", val);	// Print cleartext input as hex
		if(i%10==9){
			printf("\n");
		}
	}
}

	// Encrypts and prints the given cleartext input as hex characters using the given key
void encrypt(char text[], int length, int key){
	for(int i = 0; i < length; i++){	// Convert text to cipher using key
		char clearChar = text[i];
		char cipherChar = clearChar ^ key;
		printf("%02x ", (unsigned char)cipherChar);	// Print converted text

	}
}

	// Main function

int main() {
	char clearText[201]; 		// Max length of 200 and null terminator		
	int clearTextLength = 0;	// Track length of clearText

	#ifdef PROMPT		// Get text from redirected input, no output generated
	printf("");
	#endif

	//Read and store the text until \n or max length
	int inChar;
	while((inChar = getchar()) != '\n' && clearTextLength < 200) {
		clearText[clearTextLength++] = (char)inChar;
	}
 
	clearText[clearTextLength] = '\0';	// Null terminator

	// printHex(clearText, clearTextLength); (Not used in bit_encode1)
	// printf("\n");

	char c;		// Used to store input character
	int key = 0;	// Store the 8-bit key
	int count = 0;	// count loop iterations

	#ifdef PROMPT		// Get key from redirected input, no output generated
	printf("");
	#endif
	while(c != '\n'){
		c = getchar();
		int temp1, temp2;
		if(c == '1'){
			temp1 = temp2 = 1;
			temp1 = 1 << count; 		// shift count times right
			temp2 = 1 << (count+4); 	// shift count + 4 times rights
		}
		if(c == '0'){
			temp1 = temp2 = 0; 		// no change to be made in key
		}
		key = key|temp1|temp2;
		count++;
	}

	encrypt(clearText, clearTextLength, key);

	
	printf("\n");
}

