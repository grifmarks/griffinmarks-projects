/* BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF THE
** WORK TO CREATE THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN THIS
** FILE MYSELF WITH NO ASSISTANCE FROM ANY PERSON (OTHER THAN THE INSTRUCTOR
** OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY ADHERED TO THE TENURES OF THE
** OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_TITLE_LENGTH 61

void populateTitles(char ***titles, int *numBooks) {
    printf("Enter the number of book titles: ");
    scanf("%d", numBooks);
    getchar(); // Consume the newline character in the input buffer

    *titles = (char **)malloc(*numBooks * sizeof(char *)); //Allocate array memory
    if (*titles == NULL) {
        printf("Memory allocation failed\n");
        exit(1);
    }

    printf("Enter the book titles:\n"); 	//Get book titles, allocate memory
    for (int i = 0; i < *numBooks; i++) {
        (*titles)[i] = (char *)malloc(MAX_TITLE_LENGTH * sizeof(char));
        if ((*titles)[i] == NULL) {
            printf("Memory allocation failed\n");
            exit(1);
        }
        fgets((*titles)[i], MAX_TITLE_LENGTH, stdin); //Add titles to array
        (*titles)[i][strlen((*titles)[i]) - 1] = '\0'; // Removing the newline character
    }
}

void populateFavorites(char **titles, int numBooks, char ***favorites, int *numFavorites) {
    printf("\nEnter the number of books you want to put in favorites: ");
    scanf("%d", numFavorites);
    getchar(); // Consume the newline character in the input buffer

    *favorites = (char **)malloc(*numFavorites * sizeof(char *));//Allocate memory for favorites
    if (*favorites == NULL) {
        printf("Memory allocation failed\n");
        exit(1);
    }

    printf("Enter the title numbers for favorites:\n");		//Populate favorites array
    for (int i = 0; i < *numFavorites; i++) {
        int titleNum;
        scanf("%d", &titleNum);
        getchar(); // Consume the newline character in the input buffer
        (*favorites)[i] = (titles[titleNum - 1]); // Copying the title to favorites list
    }
}

void saveToFile(char **titles, int numBooks, char **favorites, int numFavorites) {
    char fileName[100];
    printf("Enter the file name to save: ");		//Get file name
    scanf("%s", fileName);
    FILE *file = fopen(fileName, "w");
    if (file == NULL) {
        printf("Error opening file!\n");
        return;
    }
    fprintf(file, "All titles:\n");			//Output titles to file
    for (int i = 0; i < numBooks; i++) {
        fprintf(file, "%s\n", titles[i]);
    }
    fprintf(file, "Favorites:\n");			//Output favorites to file
    for (int i = 0; i < numFavorites; i++) {
        fprintf(file, "%s\n", favorites[i]);
    }
    fclose(file);					//Close file
    printf("Data has been saved to %s\n", fileName);
}

int main() {
    char **titles = NULL; 	//Initialize all variables
    int numBooks = 0;
    char **favorites = NULL;
    int numFavorites = 0;

    populateTitles(&titles, &numBooks);		//Call function to make array of titles

    printf("\nAll titles:\n");			//Print array of titles
    for (int i = 0; i < numBooks; i++) {
        printf("%d. %s\n", i + 1, titles[i]);
    }

    populateFavorites(titles, numBooks, &favorites, &numFavorites); //Call function to make 										array of favorites

    printf("\nFavorites list:\n");		//Print favorite list
    for (int i = 0; i < numFavorites; i++) {
        printf("%d. %s\n", i + 1, favorites[i]);
    }

    int choice;		//Determine if user wants an output file
    printf("\nDo you want to store the information in a file? (1 for yes, 2 for no): ");
    scanf("%d", &choice);
    if (choice == 1) {		//If yes, call fucntion to save to file
        saveToFile(titles, numBooks, favorites, numFavorites);
    }

    // Freeing dynamically allocated memory
    for (int i = 0; i < numBooks; i++) {
        free(titles[i]);
    }
    free(titles);
    free(favorites);

    return 0;
}
