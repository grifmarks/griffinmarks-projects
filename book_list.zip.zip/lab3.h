#ifndef LAB3_H
#define LAB3_H

void saveToFile(char **titles, int numTitles, char **favorites, int numFavorites);
void printTitles(char **tiels, int numTitles);
void printFavorites(char **favorites, int numFavorites);

#endif /* LAB3_H */
