BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I HAVE PERFORMED ALL OF THE WORK TO CREATE
THIS FILE AND/OR DETERMINE THE ANSWERS FOUND WITHIN THIS FILE MYSELF WITH NO ASSISTANCE
FROM ANY PERSON (OTHER THAN THE INSTRUCTOR OR GRADERS OF THIS COURSE) AND I HAVE STRICTLY
ADHERED TO THE TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
THIS IS THE README FILE FOR LAB 3.

Griffin Marks

3 hours

I didn't have any major concerns with the lab. My functions were working as expected, and I didn't have any problems applying pointers to make the arrays and strings.

I had a few minors bugs found using GDB, but no major noticeable bugs that weren't a one or two line fix. I used break points for each function in the code, which allowed me to go through step by step. This allowed me to check the contents of the arrays and make sure the titles and favorites was being populated correctly. I also set a breakpoint near the end of the program to check the memory freeing, and make sure everything was freed and working correctly.
