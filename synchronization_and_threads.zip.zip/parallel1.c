#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define ARRAY_SIZE 1000000
#define THREAD_NO 10

int sum = 0;  // Global sum variable
int num[THREAD_NO][ARRAY_SIZE / THREAD_NO];  // Array to hold nums

// Thread function to sum an array's elements
void* partial_sum(void* arg) {
    int thread_id = *(int*)arg;
    int local_sum = 0;  // Local sum to avoid interference with other threads

    // Sum the threads portin of the array
    for (int i = 0; i < ARRAY_SIZE / THREAD_NO; i++) {
        local_sum += num[thread_id][i];
    }

    sum += local_sum;  // Update the global sum
    free(arg);  // Free memory allocated for thread
    return NULL;
}

int main() {
    pthread_t threads[THREAD_NO];  // Array to hold thread IDs

    srand(100);

    // Initialize the arrays with random numbers
    for (int i = 0; i < THREAD_NO; i++) {
        for (int j = 0; j < ARRAY_SIZE / THREAD_NO; j++) {
            num[i][j] = rand() % 100;
        }
    }

    // Create 10 threads
    for (int i = 0; i < THREAD_NO; i++) {
        int* thread_id = malloc(sizeof(int));  // Allocate memory for thread
        *thread_id = i;
        pthread_create(&threads[i], NULL, partial_sum, thread_id);
    }

    // Wait for all threads to complete
    for (int i = 0; i < THREAD_NO; i++) {
        pthread_join(threads[i], NULL);
    }

    printf("sum = %d\n", sum);  // Print the final sum
    return 0;
}
