#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define ARRAY_SIZE 1000000
#define THREAD_NO 10
#define PART_SIZE (ARRAY_SIZE / THREAD_NO)

int num[ARRAY_SIZE];   // Shared array with random numbers
int sum = 0;           // Global sum variable
pthread_mutex_t sum_lock;  // Mutex lock for synchronizing access to sum

void *partial_sum(void *arg) {
    int index = *(int *)arg;  // Thread's starting index
    free(arg);  // Free the allocated memory for the argument

    int local_sum = 0;
    for (int i = index; i < index + PART_SIZE; i++) {
        local_sum += num[i];  // Calculate partial sum locally
    }

    // Lock the critical section where sum is updated
    pthread_mutex_lock(&sum_lock);
    sum += local_sum;  // Add the partial sum to the global sum
    pthread_mutex_unlock(&sum_lock);  // Unlock after updating

    return NULL;
}

int main() {
    pthread_t threads[THREAD_NO];

    // Initialize the mutex lock
    pthread_mutex_init(&sum_lock, NULL);

    srand(100);
    for (int i = 0; i < ARRAY_SIZE; i++) {
        num[i] = rand() % 100;
    }

    // Create 10 threads
    for (int i = 0; i < THREAD_NO; i++) {
        int *start_index = malloc(sizeof(int));  // Allocate memory for thread
        *start_index = i * PART_SIZE;  // Each thread gets a unique starting index
        pthread_create(&threads[i], NULL, partial_sum, start_index);
    }

    // Wait for all threads to finish
    for (int i = 0; i < THREAD_NO; i++) {
        pthread_join(threads[i], NULL);
    }

    // Print the final sum
    printf("sum = %d\n", sum);

    // Destroy the mutex lock
    pthread_mutex_destroy(&sum_lock);

    return 0;
}
