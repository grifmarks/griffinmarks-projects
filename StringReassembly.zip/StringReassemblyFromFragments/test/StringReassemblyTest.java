import static org.junit.Assert.assertEquals;

import org.junit.Test;

import components.set.Set;
import components.set.Set1L;
import components.set.Set2;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

public class StringReassemblyTest {

    /**
     * Test cases for combination method.
     */
    /**
     * Test of combination with one word, 4 letter overlap.
     */
    @Test
    public void testCombination() {
        String str1 = "testcase";
        String str2 = "case1";
        int overlap = 4;
        String result = StringReassembly.combination(str1, str2, overlap);
        assertEquals("testcase1", result);
    }

    /**
     * Test of combination with no overlap.
     */
    @Test
    public void testCombination2() {
        String str1 = "CSE";
        String str2 = "2221";
        int overlap = 0;
        String result = StringReassembly.combination(str1, str2, overlap);
        assertEquals("CSE2221", result);
    }

    /**
     * Test of combination with two strings that are the same.
     */
    @Test
    public void testCombination3() {
        String str1 = "same string";
        String str2 = "same string";
        int overlap = 11;
        String result = StringReassembly.combination(str1, str2, overlap);
        assertEquals("same string", result);
    }

    /**
     * Test of combination with 2 words, 1 letter shared.
     */
    @Test
    public void testCombination4() {
        String str1 = "one letter";
        String str2 = "r shared";
        int overlap = 1;
        String result = StringReassembly.combination(str1, str2, overlap);
        assertEquals("one letter shared", result);
    }

    /**
     * Tests of addToSetAvoidingSubtstrings method.
     */

    /**
     * Routine test of addToSetAvoidingSubstrings.
     */
    @Test
    public void testaddToSetAvoidingSubstrings1() {
        Set<String> strset = new Set1L<String>();
        Set<String> strset2 = new Set1L<String>();
        strset.add("Test1");
        strset.add("Test2");
        strset.add("Test3");
        strset2.add("Test1");
        strset2.add("Test2");
        strset2.add("Test3");
        StringReassembly.addToSetAvoidingSubstrings(strset, "Test");
        assertEquals(strset2, strset);
    }

    /**
     * Routine test of addToSetAvoidingSubstrings.
     */
    @Test
    public void testaddToSetAvoidingSubstrings2() {
        Set<String> strset = new Set1L<String>();
        Set<String> strset2 = new Set1L<String>();
        strset.add("Test1");
        strset.add("Test2");
        strset.add("Test3");
        strset2.add("Test2");
        strset2.add("Test3");
        StringReassembly.addToSetAvoidingSubstrings(strset, "Test1");
        assertEquals(strset2, strset);
    }

    /**
     * Tests of printWithLineSeparators method.
     */

    /**
     * Tests the method for a string with multiple separators.
     */
    @Test
    public void printWithLineSeparatorsTest1() {
        SimpleWriter out = new SimpleWriter1L();
        String test1 = "First ~ test ~ for ~ line ~ separators";

        StringReassembly.printWithLineSeparators(test1, out);
        out.println("\n");

        out.close();
    }

    /**
     * Tests the method for a string with multiple separators.
     */
    @Test
    public void printWithLineSeparatorsTest2() {
        SimpleWriter out = new SimpleWriter1L();
        String test1 = "Another test ~ for line ~ separators.";

        StringReassembly.printWithLineSeparators(test1, out);
        out.println("\n");

        out.close();
    }

    /**
     * Tests the method for a string with one separator.
     */
    @Test
    public void printWithLineSeparatorsTest3() {
        SimpleWriter out = new SimpleWriter1L();
        String test1 = "A third test ~ for line separators.";

        StringReassembly.printWithLineSeparators(test1, out);
        out.println("\n");

        out.close();
    }

    /**
     * Test for the linesFromInput method
     */
    @Test
    public void linesFromInput1() {

        SimpleReader file = new SimpleReader1L("data/cheer-8-2.txt");
        Set<String> strSet = new Set2<>();
        Set<String> strSet2 = new Set2<>();
        strSet2.add("Bucks -- Beat");
        strSet2.add("Go Bucks");
        strSet2.add("o Bucks -- B");
        strSet2.add("Beat Mich");
        strSet2.add("Michigan~");

        strSet = StringReassembly.linesFromInput(file);
        assertEquals(strSet2, strSet);
    }

}
