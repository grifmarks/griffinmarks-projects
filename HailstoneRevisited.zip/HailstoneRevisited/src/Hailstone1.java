import components.naturalnumber.NaturalNumber;
import components.naturalnumber.NaturalNumber2;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * Computes the hailstone series using natural numbers
 *
 * @author Griffin Marks
 *
 */
public final class Hailstone1 {

    /**
     * No argument constructor--private to prevent instantiation.
     */
    private Hailstone1() {
    }

    /**
     * Generates and outputs the Hailstone series starting with the given
     * {@code NaturalNumber}.
     *
     * @param n
     *            the starting natural number
     * @param out
     *            the output stream
     * @updates out.content
     * @requires n > 0 and out.is_open
     * @ensures out.content = #out.content * [the Hailstone series starting with
     *          n]
     */
    private static void generateSeries(NaturalNumber n, SimpleWriter out) {

        final int one = 1, two = 2, three = 3;
        NaturalNumber zeroNat = new NaturalNumber2();
        NaturalNumber oneNat = new NaturalNumber2(one);
        NaturalNumber twoNat = new NaturalNumber2(two);
        NaturalNumber threeNat = new NaturalNumber2(three);
        NaturalNumber x = new NaturalNumber2(n);
        NaturalNumber y = new NaturalNumber2(n);

        out.print(x);
        while (x.compareTo(oneNat) != 0) {
            y = x;
            if (y.divide(twoNat).isZero()) {
                out.print(" " + x);
            } else {
                x.multiply(threeNat);
                x.add(oneNat);
                out.print(" " + x);
            }
        }

    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        out.println("Enter a positive number:");
        int x = in.nextInteger();
        NaturalNumber n = new NaturalNumber2(x);
        generateSeries(n, out);

        in.close();
        out.close();
    }

}
