#ifndef _BOUNDED_BUFFER_H
#define _BOUNDED_BUFFER_H
#include <pthread.h>

/* Bounded buffer structure */
struct bounded_buffer {
    void **buffer;           // Array of void* to store items
    int size;                // Maximum size
    int head;                // Index of the next item to pop
    int tail;                // Index of the next free slot to push
    int count;               // Number of items currently in the buffer

    pthread_mutex_t mutex;   // Mutex to protect buffer access
    pthread_cond_t not_full; // Condition variable for full buffer
    pthread_cond_t not_empty; // Condition variable for empty buffer
};

/* Function prototypes */
void bounded_buffer_init(struct bounded_buffer *buffer, int size);
void bounded_buffer_push(struct bounded_buffer *buffer, void *item);
void* bounded_buffer_pop(struct bounded_buffer *buffer);
void bounded_buffer_destroy(struct bounded_buffer *buffer);

#endif
