#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <ctype.h>
#include "word_count.h"
#include "hashmap.h"
#include "bounded_buffer.h"

// Simple hash function based on sum of ASCII values modulo the number of reducers
int compute_reducer_index(const char *word, int num_reducers) {
    int hash = 0;
    while (*word) {
        hash += *word;
        word++;
    }
    return hash % num_reducers;
}

int print_result(char *key, int value);

typedef struct {
    map_t hashmap;
    struct bounded_buffer *buffer;
} reducer_args;

// Function to trim whitespace from the beginning and end of a string
char* trim_whitespace(char *str) {
    char *end;

    // Trim leading space
    while (isspace((unsigned char)*str)) str++;

    // All spaces?
    if (*str == 0)  
        return str;

    // Trim trailing space
    end = str + strlen(str) - 1;
    while (end > str && isspace((unsigned char)*end)) end--;

    // Set new null terminator
    *(end + 1) = '\0';

    return str;
}

// Reducer function to be run by each reducer thread
void *reducer(void *arg) {
    reducer_args *args = (reducer_args *)arg;
    char *word;
    int count, error;

    while ((word = (char *)bounded_buffer_pop(args->buffer)) != NULL) {
        word = trim_whitespace(word);
        error = hashmap_get(args->hashmap, word, &count);
        if (error == MAP_OK) {
            hashmap_put(args->hashmap, word, count + 1);
        } else {
            hashmap_put(args->hashmap, word, 1);
        }
    }
    return NULL;
}

void word_count(int m, int r, char **text) {
    const char delimiter[2] = " ";
    char *token;
    map_t hashmap;
    hashmap = hashmap_new();

    // Create the bounded buffers for each reducer
    struct bounded_buffer *buffers = malloc(r * sizeof(struct bounded_buffer));
    for (int i = 0; i < r; i++) {
        bounded_buffer_init(&buffers[i], 10);  // Initial buffer size 10
    }

    // Create reducer threads and assign each a buffer
    pthread_t reducer_threads[r];
    reducer_args args[r];
    for (int i = 0; i < r; i++) {
        args[i].buffer = &buffers[i];
        args[i].hashmap = hashmap;
        pthread_create(&reducer_threads[i], NULL, reducer, &args[i]);
    }

    // Process each document with mappers and distribute words to reducers
    for (int i = 0; i < m; i++) {
        token = strtok(text[i], delimiter);
        while (token != NULL) {
            token = trim_whitespace(token);  // Clean up each token
            int reducer_index = compute_reducer_index(token, r);
            bounded_buffer_push(&buffers[reducer_index], token);
            token = strtok(NULL, delimiter);
        }
    }

    // Signal reducers to finish by sending NULL to each buffer
    for (int i = 0; i < r; i++) {
        bounded_buffer_push(&buffers[i], NULL);  // NULL signals end of data
    }

    // Wait for all reducer threads to finish
    for (int i = 0; i < r; i++) {
        pthread_join(reducer_threads[i], NULL);
    }

    // Print final results
    printf("Result:\n");
    hashmap_iterate(hashmap, print_result);

    // Cleanup
    hashmap_free(hashmap);
    for (int i = 0; i < r; i++) {
        bounded_buffer_destroy(&buffers[i]);
    }
    free(buffers);
}

int print_result(char *key, int value) {
    printf("count of %s = %d\n", key, value);
    return MAP_OK;
}
