#ifndef _WORD_COUNT_H
#define _WORD_COUNT_H

void word_count(int m, int r, char **text);


#endif
