#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "word_count.h"

#define MAX_FILE_SIZE 1024 * 1024  // 1 MB buffer size

// Function to read a file into a string
char *read_file(const char *filename) {
    FILE *file = fopen(filename, "r");
    if (!file) {
        perror("Error opening file");
        return NULL;
    }

    char *buffer = malloc(MAX_FILE_SIZE);
    if (!buffer) {
        perror("Memory allocation failed");
        fclose(file);
        return NULL;
    }

    size_t size = fread(buffer, 1, MAX_FILE_SIZE - 1, file);
    buffer[size] = '\0';  // Null-terminate the string

    fclose(file);
    return buffer;
}

int main(int argc, char **args) {
    if (argc <= 3) {
        printf("Usage: ./word_count [m] [r] [m strings or files]\n");
        return -1;
    }

    int m = atoi(args[1]);
    int r = atoi(args[2]);

    if (argc - 3 != m) {
        printf("Error: m=%d, but %d strings/files\n", m, argc - 3);
        return -1;
    }

    char **text = malloc(sizeof(char*) * m);
    for (int i = 0; i < m; i++) {
        if (strchr(args[i + 3], '.') != NULL) {
            // If it's a filename, read the file contents
            text[i] = read_file(args[i + 3]);
            if (!text[i]) {
                printf("Error reading file: %s\n", args[i + 3]);
                return -1;
            }
        } else {
            // Otherwise, treat it as a string literal
            text[i] = args[i + 3];
        }
    }

    printf("m=%d, r=%d\n", m, r);
    for (int i = 0; i < m; i++) {
        printf("%s\n", text[i]);
    }

    word_count(m, r, text);

    // Free allocated memory for file content
    for (int i = 0; i < m; i++) {
        if (strchr(args[i + 3], '.') != NULL) {
            free(text[i]);  // Free memory if it was a file read
        }
    }
    free(text);

    return 0;
}
