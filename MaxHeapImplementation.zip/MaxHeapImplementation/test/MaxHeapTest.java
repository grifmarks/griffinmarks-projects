import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class MaxHeapTest {

    @Test
    public void testMaxHeap() {
        MaxHeapImplementation.MaxHeap maxHeap = new MaxHeapImplementation.MaxHeap(
                10);

        maxHeap.insert(5);
        maxHeap.insert(3);
        maxHeap.insert(8);
        maxHeap.insert(1);
        maxHeap.insert(10);

        assertEquals(10, maxHeap.extractMax()); // Max element should be 10
        assertEquals(8, maxHeap.extractMax()); // Max element should be 8
        assertEquals(5, maxHeap.extractMax()); // Max element should be 5
        assertEquals(3, maxHeap.extractMax()); // Max element should be 3
        assertEquals(1, maxHeap.extractMax()); // Max element should be 1
        assertEquals(-1, maxHeap.extractMax()); // Heap is empty, should return -1
    }

    @Test
    public void testMaxHeap2() {
        MaxHeapImplementation.MaxHeap maxHeap = new MaxHeapImplementation.MaxHeap(
                10);

        maxHeap.insert(18);
        maxHeap.insert(0);
        maxHeap.insert(130);
        maxHeap.insert(47);
        maxHeap.insert(1000);

        assertEquals(1000, maxHeap.extractMax()); // Max element should be 1000
        assertEquals(130, maxHeap.extractMax()); // Max element should be 130
        assertEquals(47, maxHeap.extractMax()); // Max element should be 47
        assertEquals(18, maxHeap.extractMax()); // Max element should be 18
        assertEquals(0, maxHeap.extractMax()); // Max element should be 0
    }

    @Test
    public void testMaxHeap3() {
        MaxHeapImplementation.MaxHeap maxHeap = new MaxHeapImplementation.MaxHeap(
                10);

        maxHeap.insert(-3);
        maxHeap.insert(-18);
        maxHeap.insert(417);
        maxHeap.insert(80);
        maxHeap.insert(0);

        assertEquals(417, maxHeap.extractMax()); // Max element should be 417
        assertEquals(80, maxHeap.extractMax()); // Max element should be 80
        assertEquals(0, maxHeap.extractMax()); // Max element should be 0
        assertEquals(-3, maxHeap.extractMax()); // Max element should be -3
        assertEquals(-18, maxHeap.extractMax()); // Max element should be -18
    }

}
