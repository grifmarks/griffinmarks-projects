/**
 * Implementation of MaxHeap in Java
 *
 * @author Griffin Marks
 */
public final class MaxHeapImplementation {

    public static class MaxHeap {
        private int[] heap;
        private int size;
        private int capacity;

        public MaxHeap(int capacity) {
            this.capacity = capacity;
            this.size = 0;
            this.heap = new int[capacity];
        }

        // Get index of parent node
        private int parent(int i) {
            return (i - 1) / 2;
        }

        // Get index of left child node
        private int leftChild(int i) {
            return 2 * i + 1;
        }

        // Get index of right child node
        private int rightChild(int i) {
            return 2 * i + 2;
        }

        // Swap two elements in the heap
        private void swap(int i, int j) {
            int temp = this.heap[i];
            this.heap[i] = this.heap[j];
            this.heap[j] = temp;
        }

        // Heapify up (after insertion)
        private void heapifyUp(int i) {
            while (i > 0 && this.heap[this.parent(i)] < this.heap[i]) {
                this.swap(i, this.parent(i));
                i = this.parent(i);
            }
        }

        // Heapify down (after extraction)
        private void heapifyDown(int i) {
            int maxIndex = i;
            int left = this.leftChild(i);
            int right = this.rightChild(i);

            if (left < this.size && this.heap[left] > this.heap[maxIndex]) {
                maxIndex = left;
            }

            if (right < this.size && this.heap[right] > this.heap[maxIndex]) {
                maxIndex = right;
            }

            if (i != maxIndex) {
                this.swap(i, maxIndex);
                this.heapifyDown(maxIndex);
            }
        }

        // Insert a new element into the heap
        public void insert(int value) {
            if (this.size == this.capacity) {
                System.out.println("Heap is full. Cannot insert.");
                return;
            }

            this.size++;
            this.heap[this.size - 1] = value;
            this.heapifyUp(this.size - 1);
        }

        // Extract the maximum element from the heap
        public int extractMax() {
            if (this.size == 0) {
                System.out.println("Heap is empty. Cannot extract.");
                return -1; // or throw an exception
            }

            int max = this.heap[0];
            this.heap[0] = this.heap[this.size - 1];
            this.size--;
            this.heapifyDown(0);

            return max;
        }

        public static void main(String[] args) {
            MaxHeap maxHeap = new MaxHeap(10);
            maxHeap.insert(5);
            maxHeap.insert(3);
            maxHeap.insert(8);
            maxHeap.insert(1);
            maxHeap.insert(10);

            System.out.println("Max element: " + maxHeap.extractMax()); // Output: 10
            System.out.println("Max element: " + maxHeap.extractMax()); // Output: 8
        }
    }
}
