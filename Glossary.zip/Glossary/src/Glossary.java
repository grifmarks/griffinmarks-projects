import components.map.Map;
import components.map.Map1L;
import components.queue.Queue;
import components.queue.Queue1L;
import components.set.Set;
import components.set.Set1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * Creates a glossary, a list of terms and their definitions, from a given html
 * file.
 *
 * @author Griffin Marks
 *
 */

public final class Glossary {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private Glossary() {
    }

    /**
     * Gets all terms from the given input file and places them into a Queue.
     *
     * @param input
     *            The given input file
     * @param termAndDef
     *            The output for all terms and definitions
     * @return all terms in alphabetical order
     */
    public static Queue<String> getTermsAndDef(SimpleReader input,
            Map<String, String> termAndDef) {
        Queue<String> terms = new Queue1L<>();
        // While loop to go through input //
        while (!input.atEOS()) {
            // Gets the next term //
            String term = input.nextLine();
            StringBuilder definition = new StringBuilder();
            boolean nextTerm = false;
            // While loop to get definition of the term //
            while (!nextTerm) {
                String line = input.nextLine();
                if (!line.equals("")) {
                    definition.append(line + " ");
                } else {
                    // Remove any trailing spaces //
                    definition.deleteCharAt(definition.length() - 1);
                    nextTerm = true;
                }
            }
            /*
             * Adds the term and its corresponding definition to {@code
             * termAndDef}, as well as to {@code terms}.
             */
            termAndDef.add(term, definition.toString());
            terms.enqueue(term);
        }
        /* Sorts {@code terms}. */
        terms.sort(String.CASE_INSENSITIVE_ORDER);
        return terms;
    }

    /**
     * Generates a title page for the glossary, linking to each term.
     *
     * @param fileOutput
     *            The output to the glossary file
     * @param terms
     *            The list of all terms from the input in alphabetical order
     */

    public static void generateTitlePage(SimpleWriter fileOutput,
            Queue<String> terms) {
        fileOutput.println("<html>");
        fileOutput.println(" <head>");
        fileOutput.println(" <title>Glossary</title>");
        fileOutput.println(" </head>");
        fileOutput.println(" <body>");
        fileOutput.println(" <h2>Glossary</h2>");
        fileOutput.println(" <hr>");
        fileOutput.println(" <h3>Index</h3>");
        fileOutput.println(" <ul>");
        // For loop to hyperlink the terms on each page //
        for (int i = 0; i < terms.length(); i++) {
            fileOutput.println(" <li>");
            fileOutput.println(" <a href=\"" + terms.front() + ".html\">"
                    + terms.front() + "</a>");
            fileOutput.println(" </li>");
            terms.rotate(1);
        }

        fileOutput.println(" </ul>");
        fileOutput.println(" </body>");
        fileOutput.println("</html>");

    }

    /**
     * Prints the terms and their respective definitions in alphabetical order.
     *
     * @param fileOutput
     *            The output to the glossary file
     * @param term
     * @param termsAndDef
     */
    public static void generateTermPage(SimpleWriter fileOutput, String term,
            Map<String, String> termsAndDef) {
        fileOutput.println("<html>");
        fileOutput.println(" <head>");
        fileOutput.println(" <title>" + term + "</title>");
        fileOutput.println(" </head>");
        fileOutput.println(" <body>");
        fileOutput.println("<h2><b><i><font color=\"red\">" + term
                + "</font></i></b></h2>");
        /*
         * Prints to fileOutput the term and its corresponding definition, in
         * html format
         */
        fileOutput.println(
                "<blockquote>" + termsAndDef.value(term) + "</blockquote>");
        fileOutput.println(" <hr>");
        fileOutput
                .println("<p>Return to <a href=\"index.html\">index</a>.</p>");
        fileOutput.println(" </body>");
    }

    /**
     * Checks for any repeated terms, and if one is found, links it's
     * definition.
     *
     * @param terms
     *            The list of terms from the input file
     * @param termsAndDef
     *            The list of terms and definitions from the input file
     */

    public static void updateDefinition(Queue<String> terms,
            Map<String, String> termsAndDef) {
        /* Set of separators. */
        Set<Character> separators = new Set1L<>();
        separators.add(',');
        separators.add(' ');
        separators.add('\t');
        separators.add(';');
        separators.add('.');
        // For loops to check for any definition that containers another term //
        for (int i = 0; i < terms.length(); i++) {
            String term = terms.front();
            for (int q = 0; q < terms.length(); q++) {
                String curTerm = terms.front();
                String definition = termsAndDef.value(term);
                int position = 0;
                while (position < definition.length()) {
                    String curWord = nextWordOrSeparator(definition, position,
                            separators);
                    /*
                     * If a term is found, link the definition in the page
                     */
                    if (curWord.equals(curTerm)) {
                        definition = definition.substring(0, position)
                                + "<a href=\"" + curWord + ".html\">" + curWord
                                + "</a>"
                                + definition.substring(
                                        position + curWord.length(),
                                        definition.length());
                    }
                    position += curWord.length();
                }
                termsAndDef.replaceValue(term, definition);
                terms.rotate(1);
            }
            terms.rotate(1);
        }
    }

    /**
     * Returns the first "word" (maximal length string of characters not in
     * {@code separators}) or "separator string" (maximal length string of
     * characters in {@code separators}) in the given {@code text} starting at
     * the given {@code position}.
     *
     * @param text
     *            the {@code String} from which to get the word or separator
     *            string
     * @param position
     *            the starting index
     * @param separators
     *            the {@code Set} of separator characters
     * @return the first word or separator string found in {@code text} starting
     *         at index {@code position}
     * @requires 0 <= position < |text|
     * @ensures <pre>
     * nextWordOrSeparator =
     *   text[position, position + |nextWordOrSeparator|)  and
     * if entries(text[position, position + 1)) intersection separators = {}
     * then
     *   entries(nextWordOrSeparator) intersection separators = {}  and
     *   (position + |nextWordOrSeparator| = |text|  or
     *    entries(text[position, position + |nextWordOrSeparator| + 1))
     *      intersection separators /= {})
     * else
     *   entries(nextWordOrSeparator) is subset of separators  and
     *   (position + |nextWordOrSeparator| = |text|  or
     *    entries(text[position, position + |nextWordOrSeparator| + 1))
     *      is not subset of separators)
     * </pre>
     */

    public static String nextWordOrSeparator(String text, int position,
            Set<Character> separators) {
        assert text != null : "Violation of: text is not null";
        assert separators != null : "Violation of: separators is not null";
        assert 0 <= position : "Violation of: 0 <= position";
        assert position < text.length() : "Violation of: position < |text|";

        StringBuilder returnText = new StringBuilder();
        if (separators.contains(text.charAt(position))) {
            for (int i = position; i < text.length()
                    && separators.contains(text.charAt(i)); i++) {
                returnText.append(text.charAt(i));
            }
        } else {
            for (int i = position; i < text.length()
                    && !separators.contains(text.charAt(i)); i++) {
                returnText.append(text.charAt(i));
            }
        }
        return returnText.toString();
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        /*
         * Prompt the user for the location of the input file and the desired
         * location for the output.
         */
        out.println("Enter the input file: ");
        String inputFile = in.nextLine();
        out.println("Enter the folder to save output files to: ");
        String outputLocation = in.nextLine();

        SimpleReader input = new SimpleReader1L(inputFile);

        Map<String, String> termsAndDef = new Map1L<>();
        Queue<String> terms = getTermsAndDef(input, termsAndDef);
        updateDefinition(terms, termsAndDef);

        //Create a title page //
        SimpleWriter output = new SimpleWriter1L(
                outputLocation + "\\index.html");
        generateTitlePage(output, terms);

        // Create a page for each term //
        int length = terms.length();
        for (int i = 0; i < length; i++) {
            String term = terms.dequeue();
            output = new SimpleWriter1L(outputLocation + "\\" + term + ".html");
            generateTermPage(output, term, termsAndDef);
        }

        in.close();
        out.close();
        input.close();
        output.close();
    }
}
