/**
 * Simple implementation of InsertionSort.
 *
 * @author Griffin Marks
 */
public final class InsertionSort {

    private InsertionSort() {
        // no code needed here
    }

    /**
     * Implementation of Insertion Sort.
     */
    public static void insertionSort(int array[]) {
        int n = array.length;
        for (int j = 1; j < n; j++) {
            int k = array[j];
            int i = j - 1;
            while ((i > -1) && (array[i] > k)) {
                array[i + 1] = array[i];
                i--;
            }
            array[i + 1] = k;
        }
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */

    public static void main(String[] args) {

        long startTime = System.currentTimeMillis();

        // Testing with standard array

        int[] arr1 = { 8, 17, 3, 1, 53, 13, 62, 22 };
        System.out.println("Before Insertion Sort");
        for (int i : arr1) {
            System.out.print(i + " ");
        }
        System.out.println();

        insertionSort(arr1); // sorting array using insertion sort

        System.out.println("After Insertion Sort");
        for (int i : arr1) {
            System.out.print(i + " ");
        }
        System.out.println("\n");

        // Testing for an array of size 1000

        int arr2[] = new int[1000];
        for (int i = 0; i < 1000; i++) {
            double rand = Math.random() * 1000;
            arr2[i] = (int) rand;
        }

        System.out.println("Before Insertion Sort");
        for (int i : arr2) {
            System.out.print(i + " ");
        }
        System.out.println();

        insertionSort(arr2); // sorting array using insertion sort

        System.out.println("After Insertion Sort");
        for (int i : arr2) {
            System.out.print(i + " ");

        }
        long endTime = System.currentTimeMillis();
        System.out.println("\n\nTime = " + (endTime - startTime) + " ms");
    }
}
