import static org.junit.Assert.assertArrayEquals;

import org.junit.Test;

/**
 * @author Griffin Marks
 *
 */

public class InsertionSortTest {

    @Test
    public void ISTest1() {
        int[] arr1 = { 8, 17, 3 };
        int[] arr2 = { 3, 8, 17 };
        InsertionSort.insertionSort(arr1);
        assertArrayEquals(arr1, arr2);
    }

    @Test
    public void ISTest2() {
        int[] arr1 = { 34, 560, 12 };
        int[] arr2 = { 12, 34, 560 };
        InsertionSort.insertionSort(arr1);
        assertArrayEquals(arr1, arr2);
    }

    @Test
    public void ISTest3() {
        int[] arr1 = { 9, 84, 20, 101, 57 };
        int[] arr2 = { 9, 20, 57, 84, 101 };
        InsertionSort.insertionSort(arr1);
        assertArrayEquals(arr1, arr2);
    }

    @Test
    public void ISTest4() {
        int[] arr1 = { 7, 9, 3, 5, 1, 8, 2, 4, 6 };
        int[] arr2 = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
        InsertionSort.insertionSort(arr1);
        assertArrayEquals(arr1, arr2);
    }

}
