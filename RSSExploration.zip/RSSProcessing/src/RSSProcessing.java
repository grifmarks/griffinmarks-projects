import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;
import components.xmltree.XMLTree;
import components.xmltree.XMLTree1;

/**
 * This program inputs an XML RSS (version 2.0) feed from a given URL and
 * outputs various elements of the feed to the console.
 *
 * @author Put your name here
 *
 */
public final class RSSProcessing {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private RSSProcessing() {
    }

    /**
     * Finds the first occurrence of the given tag among the children of the
     * given {@code XMLTree} and return its index; returns -1 if not found.
     *
     * @param xml
     *            the {@code XMLTree} to search
     * @param tag
     *            the tag to look for
     * @return the index of the first child of the {@code XMLTree} matching the
     *         given tag or -1 if not found
     * @requires [the label of the root of xml is a tag]
     * @ensures <pre>
     * getChildElement =
     *  [the index of the first child of the {@code XMLTree} matching the
     *   given tag or -1 if not found]
     * </pre>
     */
    private static int getChildElement(XMLTree xml, String tag) {
        assert xml != null : "Violation of: xml is not null";
        assert tag != null : "Violation of: tag is not null";
        assert xml.isTag() : "Violation of: the label root of xml is a tag";
        boolean flag = true;
        int index = -1, i = 0;

        while (flag) {
            if (xml.child(i).isTag()) {
                String x = xml.child(i).label();
                if (x.equals(tag)) {
                    flag = false;
                    index = i;
                }
                i++;

            }
            if (i >= xml.numberOfChildren()) {
                flag = false;
            }
        }
        return index;

    }

    /**
     * Processes one news item and outputs the title, or the description if the
     * title is not present, and the link (if available) with appropriate
     * labels.
     *
     * @param item
     *            the news item
     * @param out
     *            the output stream
     * @requires [the label of the root of item is an <item> tag] and
     *           out.is_open
     * @ensures out.content = #out.content * [the title (or description) and
     *          link]
     */
    private static void processItem(XMLTree item, SimpleWriter out) {
        assert item != null : "Violation of: item is not null";
        assert out != null : "Violation of: out is not null";
        assert item.isTag() && item.label().equals("item") : ""
                + "Violation of: the label root of item is an <item> tag";
        assert out.isOpen() : "Violation of: out.is_open";

        int titleIndex = getChildElement(item, "title");
        if (item.child(titleIndex).numberOfChildren() >= 0) {
            out.println("Title: " + item.child(titleIndex).child(0));
        } else {
            int descIndex = getChildElement(item, "description");
            out.println("Description: " + item.child(descIndex).child(0));
        }

        int linkIndex = getChildElement(item, "link");
        if (linkIndex > -1) {
            out.println(item.child(linkIndex).child(0));
        }

        int pubDateIndex = getChildElement(item, "pubDate");
        if (pubDateIndex > -1) {
            out.println(item.child(pubDateIndex).child(0));
        } else {
            out.println("Publication date not present.");
        }

        int sourceIndex = getChildElement(item, "source");
        if (sourceIndex > -1) {
            out.println(item.child(sourceIndex).child(0));
        } else {
            out.println("Source not present.");
        }

    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments; unused here
     */
    public static void main(String[] args) {

        public static void main(String[] args) {
            SimpleReader in = new SimpleReader1L();
            SimpleWriter out = new SimpleWriter1L();

            // Ask for the index xml
            out.println("Please enter an index xml: ");
            String url0 = in.nextLine();

            // Output it into a html file
            SimpleWriter fileOut = new SimpleWriter1L("index.html");
            XMLTree index = new XMLTree1(url0);

            // Use a for loop to generate html pages of it
            for (int i = 0; i < index.numberOfChildren(); i++) {
            String fileName = index.child(i).attributeValue("file");
            String urlName = index.child(i).attributeValue("url");
            processFeed(urlName, fileName, out);
            }

            // Get the title name
            String title = index.attributeValue("title");
            // Print the index page
            fileOut.print("<html>\n" + "<head>\n" + "\t<title>" + title
            + "</title>\n" + "</head>\n" + "<body>\n" + "<head>\n"
            + "\t<h1>\n" + title + "\t</h1>\n" + "</head>\n" + "\t<ul>\n");
            for (int j = 0; j < index.numberOfChildren(); j++) {
            String name = index.child(j).attributeValue("name");
            String fileName = index.child(j).attributeValue("file");
            fileOut.print("\t<li>\n" + "\t<p>\n" + "\t\t<a href=\"" + fileName
            + "\">" + name + "</a>\n" + "\t</p>\n" + "\t</li>\n");
            }
            fileOut.print("\t</ul>\n" + "</body>\n" + "</html>");

            in.close();
            out.close();
            fileOut.close();
            }

            }

}
