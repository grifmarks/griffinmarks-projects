This project implements the popular SET card game in JavaScript, using HTML and CSS for webpage design. Players identify sets of cards based on their attributes. The game supports two players, keeps track of scores, and ends when no more cards are available.

The game can be ran using the Visual Studio Code extension Live Server or a similar alternative

How to play:

The goal is to identify a set of 3 cards where, for all 4 properties, all 3 cards have the same variant or all 3 have a different variant.

The attributes are as follows:
Number of Symbols: 1, 2, 3
Shape: Oval, Square, Diamond
Shading: Solid, Striped, Open
Color: Red, Green, Purple

Examples of sets:

1. Valid set
Card 1: 2 Solid Red Diamonds
Card 2: 1 Purple Solid Diamond
Card 3: 3 Green Solid Diamonds

Numbers are all different, shapes are all the same, shadings are all the same, colors are all different

2. Invalid set
Card 1: 2 Purple Solid Diamonds
Card 2: 1 Purple Solid Diamond
Card 3: 2 Green Solid Diamonds

Since the numbers and colors aren't all different or the same, this set is invalid

Simple Game Flow:

Add Players
Start Game: Deal 12 cards
Select Cards: Players are asked to select 3 different cards. The game will check if the set is correct or incorrect
Correct Set: Player scores a point, replace the 3 cards that were used, next players turn
Incorrect set: Player gets no points, no cards replaced, next players turn
End Game: The game ends when no more sets can be found and the deck is empty. Whichever player has the highest score wins.
