let deck = []; //an array of objects used to represent a deck
let dealtCards = []; //an array of objects for the cards in play
let set = []; //an array of objects to represent a set
player = 1; //1 for player 1, -1 for player 2
scorePlayer1 = 0;
scorePlayer2 = 0;

function generateDeck() {
    colors = ["red", "green", "purple"];
    shadings = ["open", "striped", "full"];
    shapes = ["diamond", "oval", "squiggle"];
    cardNum = 0;
    for (let i = 0; i < 3; i++) {
        // nested for loop to add a card of each possible attribute combo
        for (let j = 0; j < 3; j++) {
            for (let k = 0; k < 3; k++) {
                for (let l = 1; l < 4; l++) {
                    deck.push({
                        //each object represents a card with key value pairs for each attribute
                        color: colors[i],
                        shading: shadings[j],
                        shape: shapes[k],
                        count: l,
                        img: cardNum, //this value is used to find the correct png in the images folder
                    });
                    cardNum++;
                }
            }
        }
    }
}

function dealCards(num) {
    let cardContainer = document.getElementById("card-container"); //get card container
    for (let i = 0; i < num; i++) {
        //loop to add a card for the number of times specified
        let randNum = Math.floor(Math.random() * deck.length); // pick a random index of deck
        let cardNum = deck[randNum].img;
        dealtCards.push(deck[randNum]); // add random card from deck to dealtCards
        deck = deck.filter(function (obj) {
            return obj.img != cardNum;
        }); // remove card from deck
        let image = document.createElement("img"); // create img element for card and add to card container
        let src = "images/" + cardNum + ".png";
        let onClick = "addToSet(" + cardNum + ")";
        image.setAttribute("src", src);
        image.setAttribute("class", "card");
        image.setAttribute("onClick", onClick);
        image.setAttribute("id", cardNum);
        cardContainer.appendChild(image);
    }

    updateDeckCount();
    noSetNotification(); // notify player if no set after dealing cards
    // check and report if game ends after dealing cards
    if (gameEnd()) {
        endGameReport();
    }
}

function addToSet(num) {
    if (set.length < 3 && !set.some((item) => item.img == num)) {
        // only adds card if its not already in set and if set doesnt have 3 elements
        document.getElementById(num).setAttribute("class", "card selected"); // change class to show green border
        set.push(dealtCards.find((item) => item.img == num)); // find object with specified image number in dealtCards and add to set
    } else if (set.some((item) => item.img == num)) {
        // if card that was already selected gets clicked again
        document.getElementById(num).setAttribute("class", "card"); // change class to remove green border
        set = set.filter(function (obj) {
            return obj.img != num;
        }); // remove the card from the set
    }
}

function makeSet() {
    if (validateSet()) {
        // if set is valid
        for (let i = 0; i < 3; i++) {
            // remove each card in set from the dom and from dealtCards
            document.getElementById(set[i].img).remove();
            dealtCards = dealtCards.filter(function (obj) {
                return obj.img != set[i].img;
            });
        }
        set = []; // make set empty again
        // increment score for current player
        if (player == 1) {
            scorePlayer1 += 1;
            document.getElementById(
                "player1-score"
            ).innerHTML = `Player1's Score: ${scorePlayer1}`;
        } else {
            scorePlayer2 += 1;
            document.getElementById(
                "player2-score"
            ).innerHTML = `Player2's Score: ${scorePlayer2}`;
        }
        noSetNotification(); // notify players if no set after a set is removed
    } else {
        alert("invalid set"); // alert if set isn't valid
    }

    document.getElementById("hint").style.display = "none"; // hide hint after making set

    switchPlayer(); // switch player

    // check and report if game ends after a set is removed
    if (gameEnd()) {
        endGameReport();
    }
}

function validateSet() {
    let complete = set.length == 3; // check if set has 3 cards

    cardShades = [set[0].shading, set[1].shading, set[2].shading]; // for each attribute, make an array
    validShades =
        [...new Set(cardShades)].length == 1 ||
        [...new Set(cardShades)].length == 3; // only valid if there is either 1 or 3 unique elements

    cardColors = [set[0].color, set[1].color, set[2].color];
    validColors =
        [...new Set(cardColors)].length == 1 ||
        [...new Set(cardColors)].length == 3;

    cardShapes = [set[0].shape, set[1].shape, set[2].shape];
    validShapes =
        [...new Set(cardShapes)].length == 1 ||
        [...new Set(cardShapes)].length == 3;

    cardCounts = [set[0].count, set[1].count, set[2].count];
    validCounts =
        [...new Set(cardCounts)].length == 1 ||
        [...new Set(cardCounts)].length == 3;

    return complete && validShades && validColors && validShapes && validCounts; // valid only if all attribute combinations are valid
}

function startGame() {
    generateDeck();
    dealCards(12);
    updateDeckCount();
    document.getElementById("new-game").remove();
    document.getElementById("turn").style.display = "block";
    document.getElementById("turn").innerHTML = `Player1's Turn!`;

    // adding restart-game button once new-game is clicked
    document.getElementById("restart-game").style.display = "inline";
}

function restartGame() {
    // reset all variables
    deck = [];
    dealtCards = [];
    set = [];
    player = 1;
    scorePlayer1 = 0;
    scorePlayer2 = 0;

    // clear all cards dealt and reset the score
    cardsDealt = document.getElementById("card-container");
    while (cardsDealt.firstChild) {
        cardsDealt.removeChild(cardsDealt.firstChild);
    }

    // reset scoreboard and set player to player 1
    document.getElementById("player1-score").innerHTML = "Player1's Score: 0";
    document.getElementById("player2-score").innerHTML = "Player2's Score: 0";
    document.getElementById("turn").innerHTML = `Player1's Turn!`;

    generateDeck();
    dealCards(12);
    updateDeckCount();
}

function gameEnd() {
    // end game if no valid set and number of remaining cards in deck less than 3
    if (!hasSet() && deck.length < 3) {
        return true;
    }
    return false;
}

function hasSet() {
    for (let i = 0; i < dealtCards.length - 2; i++) {
        for (let j = i + 1; j < dealtCards.length - 1; j++) {
            for (let k = j + 1; k < dealtCards.length; k++) {
                // temporary set to be checked
                let tempSet = [dealtCards[i], dealtCards[j], dealtCards[k]];

                // check if the temporary set is a valid set
                if (tempValidateSet(tempSet)) {
                    return true;
                }
            }
        }
    }
    return false; // return false if no valid set is found
}

function noSetNotification() {
    // check if there is set, generate a notification if not
    notification = document.getElementById("no-set-notification");
    if (!hasSet()) {
        notification.style.display = "block";
        document.getElementById("hint").style.display = "none";
        document.getElementById("show-hint").style.display = "none";
    } else {
        notification.style.display = "none";
        document.getElementById("show-hint").style.display = "inline";
    }
}

function showHint() {
    for (let i = 0; i < dealtCards.length - 2; i++) {
        for (let j = i + 1; j < dealtCards.length - 1; j++) {
            for (let k = j + 1; k < dealtCards.length; k++) {
                // temporary set to be checked
                tempSet = [dealtCards[i], dealtCards[j], dealtCards[k]];

                // print the set if valid
                if (tempValidateSet(tempSet)) {
                    hintDiv = document.getElementById("hint");
                    hintDiv.style.display = "block";

                    hintDiv.innerHTML = `Hint: ${i + 1},${j + 1},${k + 1}`;
                    return;
                }
            }
        }
    }
}

function tempValidateSet(currSet) {
    cardShades = [currSet[0].shading, currSet[1].shading, currSet[2].shading]; // for each attribute, make an array
    validShades =
        [...new Set(cardShades)].length == 1 ||
        [...new Set(cardShades)].length == 3; // only valid if there is either 1 or 3 unique elements

    cardColors = [currSet[0].color, currSet[1].color, currSet[2].color];
    validColors =
        [...new Set(cardColors)].length == 1 ||
        [...new Set(cardColors)].length == 3;

    cardShapes = [currSet[0].shape, currSet[1].shape, currSet[2].shape];
    validShapes =
        [...new Set(cardShapes)].length == 1 ||
        [...new Set(cardShapes)].length == 3;

    cardCounts = [currSet[0].count, currSet[1].count, currSet[2].count];
    validCounts =
        [...new Set(cardCounts)].length == 1 ||
        [...new Set(cardCounts)].length == 3;

    return validShades && validColors && validShapes && validCounts;
}

function switchPlayer() {
    player = -player;
    if (player == 1) {
        document.getElementById("turn").innerHTML = `Player1's Turn!`;
    } else {
        document.getElementById("turn").innerHTML = `Player2's Turn!`;
    }
}

function endGameReport() {
    if (scorePlayer1 > scorePlayer2) {
        alert("Game end, player 1 win!!");
    } else if (scorePlayer1 < scorePlayer2) {
        alert("Game end, player 2 win!!");
    } else {
        alert("Game end, draw game");
    }
    document.getElementById(
        "no-set-notification"
    ).innerHTML = `Game end, please restart game.`;
}

function updateDeckCount() {
    document.getElementById("deck-count").innerHTML = `Cards left in deck: ${deck.length}`;
}