import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

public class KruskalsAlgorithmTest {

    @Test
    public void testSimpleGraph() {
        List<KruskalsAlgorithm.Edge> edges = new ArrayList<>();
        edges.add(new KruskalsAlgorithm.Edge(0, 1, 4));
        edges.add(new KruskalsAlgorithm.Edge(0, 2, 1));
        edges.add(new KruskalsAlgorithm.Edge(1, 2, 9));
        edges.add(new KruskalsAlgorithm.Edge(1, 3, 5));
        edges.add(new KruskalsAlgorithm.Edge(2, 3, 6));
        edges.add(new KruskalsAlgorithm.Edge(2, 4, 10));
        edges.add(new KruskalsAlgorithm.Edge(3, 4, 8));

        List<KruskalsAlgorithm.Edge> mst = KruskalsAlgorithm.kruskalMST(edges,
                5);

        assertEquals(4, mst.size()); // MST should have n-1 edges for a connected graph

    }

    @Test
    public void testEmptyGraph() {
        List<KruskalsAlgorithm.Edge> edges = new ArrayList<>();
        List<KruskalsAlgorithm.Edge> mst = KruskalsAlgorithm.kruskalMST(edges,
                0);

        assertTrue(mst.isEmpty()); // MST of an empty graph should be empty
    }

    @Test
    public void testGraphWithNegativeWeights() {
        List<KruskalsAlgorithm.Edge> edges = new ArrayList<>();
        edges.add(new KruskalsAlgorithm.Edge(0, 1, -4));
        edges.add(new KruskalsAlgorithm.Edge(0, 2, 1));
        edges.add(new KruskalsAlgorithm.Edge(1, 2, 9));
        edges.add(new KruskalsAlgorithm.Edge(1, 3, 5));
        edges.add(new KruskalsAlgorithm.Edge(2, 3, 6));
        edges.add(new KruskalsAlgorithm.Edge(2, 4, 10));
        edges.add(new KruskalsAlgorithm.Edge(3, 4, 8));

        List<KruskalsAlgorithm.Edge> mst = KruskalsAlgorithm.kruskalMST(edges,
                5);

    }

}
