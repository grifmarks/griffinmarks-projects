import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Implementation of Kruskal's algorithm using Java's standard library
 *
 * @author P. Bucci
 */

class KruskalsAlgorithm {
    static class Edge implements Comparable<Edge> {
        int src, dest, weight;

        public Edge(int src, int dest, int weight) {
            this.src = src;
            this.dest = dest;
            this.weight = weight;
        }

        @Override
        public int compareTo(Edge other) {
            return Integer.compare(this.weight, other.weight);
        }
    }

    static class DisjointSet {
        int[] parent;

        public DisjointSet(int n) {
            this.parent = new int[n];
            for (int i = 0; i < n; i++) {
                this.parent[i] = i;
            }
        }

        int find(int x) {
            if (this.parent[x] != x) {
                this.parent[x] = this.find(this.parent[x]);
            }
            return this.parent[x];
        }

        void union(int x, int y) {
            int rootX = this.find(x);
            int rootY = this.find(y);
            if (rootX != rootY) {
                this.parent[rootX] = rootY;
            }
        }
    }

    static List<Edge> kruskalMST(List<Edge> edges, int n) {
        Collections.sort(edges);
        List<Edge> result = new ArrayList<>();
        DisjointSet dsu = new DisjointSet(n);

        for (Edge edge : edges) {
            if (dsu.find(edge.src) != dsu.find(edge.dest)) {
                result.add(edge);
                dsu.union(edge.src, edge.dest);
            }
            if (result.size() == n - 1) {
                break;
            }
        }
        return result;
    }

    public static void main(String[] args) {
        int n = 5; // Number of nodes
        List<Edge> edges = new ArrayList<>();
        edges.add(new Edge(0, 1, 4));
        edges.add(new Edge(0, 2, 1));
        edges.add(new Edge(1, 2, 9));
        edges.add(new Edge(1, 3, 5));
        edges.add(new Edge(2, 3, 6));
        edges.add(new Edge(2, 4, 10));
        edges.add(new Edge(3, 4, 8));

        List<Edge> mst = kruskalMST(edges, n);
        System.out.println("Minimum Spanning Tree edges:");
        for (Edge edge : mst) {
            System.out.println(
                    edge.src + " - " + edge.dest + " (" + edge.weight + ")");
        }
    }
}