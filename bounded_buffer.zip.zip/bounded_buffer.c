#include "bounded_buffer.h"
#include <stdio.h>
#include <stdlib.h>

/* Initialize the buffer with given size */
void bounded_buffer_init(struct bounded_buffer *buffer, int size) {
    buffer->buffer = malloc(size * sizeof(void*)); // Allocate space
    buffer->size = size;
    buffer->head = 0;
    buffer->tail = 0;
    buffer->count = 0;

    // Initialize mutex and condition variables
    pthread_mutex_init(&buffer->mutex, NULL);
    pthread_cond_init(&buffer->not_full, NULL);
    pthread_cond_init(&buffer->not_empty, NULL);
}

void bounded_buffer_push(struct bounded_buffer *buffer, void *item) {
    pthread_mutex_lock(&buffer->mutex);  // Lock the mutex

    // Wait if the buffer is full
    while (buffer->count == buffer->size) {
        pthread_cond_wait(&buffer->not_full, &buffer->mutex);
    }

    // Add the item to the buffer
    buffer->buffer[buffer->tail] = item;
    buffer->tail = (buffer->tail + 1) % buffer->size;
    buffer->count++;

    // Signal that the buffer is not empty
    pthread_cond_signal(&buffer->not_empty);

    pthread_mutex_unlock(&buffer->mutex);  // Unlock the mutex
}

void* bounded_buffer_pop(struct bounded_buffer *buffer) {
    pthread_mutex_lock(&buffer->mutex);  // Lock the mutex

    // Wait if the buffer is empty
    while (buffer->count == 0) {
        pthread_cond_wait(&buffer->not_empty, &buffer->mutex);
    }

    // Remove the item from the buffer
    void *item = buffer->buffer[buffer->head];
    buffer->head = (buffer->head + 1) % buffer->size;
    buffer->count--;

    // Signal that the buffer is not full
    pthread_cond_signal(&buffer->not_full);

    pthread_mutex_unlock(&buffer->mutex);  // Unlock the mutex
    return item;
}

/* Destroy the buffer and free resources */
void bounded_buffer_destroy(struct bounded_buffer *buffer) {
    free(buffer->buffer);

    // Destroy the mutex and condition variables
    pthread_mutex_destroy(&buffer->mutex);
    pthread_cond_destroy(&buffer->not_full);
    pthread_cond_destroy(&buffer->not_empty);
}
