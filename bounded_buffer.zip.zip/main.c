#include "bounded_buffer.h"
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

struct bounded_buffer queue;

void *producer(void *ptr);
void *consumer(void *ptr);

int main() {
    /* Initialize the queue */
    bounded_buffer_init(&queue, 5);

    /* Create producer and consumer threads */
    pthread_t producers[3], consumers[2];
    for (int i = 0; i < 3; i++)
        pthread_create(&producers[i], NULL, producer, (void *)(size_t)(i + 1));
    for (int i = 0; i < 2; i++)
        pthread_create(&consumers[i], NULL, consumer, NULL);

    /* Wait for producers */
    for (int i = 0; i < 3; i++)
        pthread_join(producers[i], NULL);

    /* Send termination signals to consumers */
    for (int i = 0; i < 2; i++)
        bounded_buffer_push(&queue, NULL);

    /* Wait for consumers */
    for (int i = 0; i < 2; i++)
        pthread_join(consumers[i], NULL);

    /* Cleanup */
    bounded_buffer_destroy(&queue);
    printf("Program exited successfully.\n");
    return 0;
}

void *producer(void *ptr) {
    int id = (int)(size_t)ptr;
    for (int i = 0; i < 10; i++) {
        int *item = malloc(sizeof(int));
        *item = id * 100 + i;
        printf("Producer %d: Pushing %d\n", id, *item);
        bounded_buffer_push(&queue, item);
    }
    return NULL;
}

void *consumer(void *ptr __attribute__((unused))) {
    while (1) {
        int *item = (int *)bounded_buffer_pop(&queue);
        if (item == NULL) {  // Stop signal received
            break;
        }
        printf("Consumer %ld: Popped %d\n", pthread_self(), *item);
        free(item);
    }
    return NULL;
}
