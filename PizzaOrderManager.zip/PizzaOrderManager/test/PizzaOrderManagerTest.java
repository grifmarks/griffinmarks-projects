import static org.junit.Assert.assertEquals;

import org.junit.Test;

import components.map.Map;
import components.map.Map1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

public class PizzaOrderManagerTest {

    @Test
    public void getPriceMapTest() {
        Map<String, Integer> sizesMap = new Map1L<String, Integer>();
        sizesMap.add("small", 795);
        sizesMap.add("medium", 995);
        sizesMap.add("large", 1295);
        sizesMap.add("biggie", 1595);
        sizesMap.add("great biggie", 1995);
        Map<String, Integer> sizesMap2 = new Map1L<String, Integer>();
        PizzaOrderManager.getPriceMap("data/sizes.txt", sizesMap2);
        assertEquals(sizesMap, sizesMap2);

    }

    @Test
    public void getOneOrder() {
        SimpleReader in = new SimpleReader1L("data/orders.txt");
        Map<String, Integer> sizesMap = new Map1L<String, Integer>();
        PizzaOrderManager.getPriceMap("data/sizes.txt", sizesMap);
        Map<String, Integer> toppingsMap = new Map1L<String, Integer>();
        PizzaOrderManager.getPriceMap("data/toppings.txt", toppingsMap);
        int price = PizzaOrderManager.getOneOrder(in, sizesMap, toppingsMap);
        assertEquals(1715, price);
    }

    @Test
    public void putPriceTest() {
        SimpleWriter out = new SimpleWriter1L();
        int price1 = 189;
        int price2 = 74;
        int price3 = 814;

        PizzaOrderManager.putPrice(out, price1);
        PizzaOrderManager.putPrice(out, price2);
        PizzaOrderManager.putPrice(out, price3);
    }
}
