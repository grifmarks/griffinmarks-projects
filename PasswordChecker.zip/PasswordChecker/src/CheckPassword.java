import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * Put a short phrase describing the program here.
 *
 * @author Put your name here
 *
 */
public final class CheckPassword {

    /**
     * No argument constructor--private to prevent instantiation.
     */
    private CheckPassword() {
    }

    /**
     * Checks whether the given String satisfies the OSU criteria for a valid
     * password. Prints an appropriate message to the given output stream.
     *
     * @param passwordCandidate
     *            the string to check
     * @param out
     *            the output stream
     *
     */
    private static void checkPassword(String passwordCandidate,
            SimpleWriter out) {

        boolean length = checkLength(passwordCandidate);

        boolean uppercase = containsUpperCaseLetter(passwordCandidate);

        boolean lowercase = containsLowerCaseLetter(passwordCandidate);

        boolean digit = containsDigit(passwordCandidate);

        boolean specialChar = containsSpecialCharacter(passwordCandidate);

        if (length && uppercase && lowercase && digit) {
            out.println("Password meets three of four requirements.");
        } else if (length && uppercase && lowercase && specialChar) {
            out.println("Password meets three of four requirements.");
        } else if (length && uppercase && digit && specialChar) {
            out.println("Password meets three of four requirements.");
        } else if (length && lowercase && digit && specialChar) {
            out.println("Password meets three of four requirements.");
        }
        if (!length) {
            out.println("Password is too short");
        }
        if (!uppercase) {
            out.println("Password doesn't contain an upper case letter.");
        }
        if (!lowercase) {
            out.println("Password doesn't contain a lower case letter");
        }
        if (!digit) {
            out.println("Password doesn't contain a digit.");
        }
        if (!specialChar) {
            out.println("Password doesn't contain a digit.");
        }

    }

    /**
     * Check if the password is of valid length.
     *
     * @param str
     *            the string to check
     * @return true if password is 8 characters or longer, flase otherwise
     */
    private static boolean checkLength(String str) {

        final int minLength = 8;
        boolean passwordLength = false;

        if (str.length() >= minLength) {
            passwordLength = true;
        } else {
            passwordLength = false;
        }

        return passwordLength;

    }

    /**
     * Check if the given string contains an upper case letter.
     *
     * @param str
     *            the String to check
     * @return true if contains upper case letter, false otherwise
     *
     */
    private static boolean containsUpperCaseLetter(String str) {

        boolean flag = false, valid = false;
        int i = 0;

        while (!flag) {
            if (i < str.length()) {
                char x = str.charAt(i);
                if (Character.isUpperCase(x)) {
                    valid = true;
                    flag = true;
                } else {
                    i++;
                }
            } else {
                flag = true;
            }
        }
        return valid;
    }

    /**
     * Check if the given string contains a lower case letter.
     *
     * @param str
     *            the String to check
     * @return true if contains lower case letter, false otherwise
     */
    private static boolean containsLowerCaseLetter(String str) {

        boolean flag = false, valid = false;
        int i = 0;

        while (!flag) {
            if (i < str.length()) {
                char x = str.charAt(i);
                if (Character.isLowerCase(x)) {
                    valid = true;
                    flag = true;
                } else {
                    i++;
                }
            } else {
                flag = true;
            }
        }
        return valid;

    }

    /**
     * Check if the given string contains a digit.
     *
     * @param str
     *            The string to check
     * @return true if string contains a digit, false otherwise
     */
    private static boolean containsDigit(String str) {

        boolean flag = false, valid = false;
        int i = 0;

        while (!flag) {
            if (i < str.length()) {
                char x = str.charAt(i);
                if (Character.isDigit(x)) {
                    valid = true;
                    flag = true;
                } else {
                    i++;
                }
            } else {
                flag = true;
            }
        }
        return valid;

    }

    /**
     * Checks if the string contains a digit.
     *
     * @param str
     *            the String to check
     * @return true if str contains a special character, false otherwise
     */
    private static boolean containsSpecialCharacter(String str) {

        boolean flag = false, valid = false;
        int i = 0;
        String specialChar = "!@#$%^&*()_-+={}[]:;,.?";
        char x = 'a';

        while (!flag) {
            x = specialChar.charAt(i);
            if (str.charAt(x) != -1) {
                flag = true;
                valid = true;
            } else {
                i++;
            }
            if (i >= str.length()) {
                flag = true;
            }

        }
        return valid;

    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        out.print("Enter your password: ");
        String password = in.nextLine();
        checkPassword(password, out);

        in.close();
        out.close();
    }

}
